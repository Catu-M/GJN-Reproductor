using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using MusicPlayer.Models;

namespace MusicPlayer.Converters;

/// <summary>
/// Convierte el estado de una línea de letra (Past/Current/Future) directamente
/// a un color: gris tenue para lo que ya pasó, blanco para lo que suena ahora,
/// gris claro para lo que falta por cantar.
/// </summary>
public class LyricStateColorConverter : IValueConverter
{
    private static readonly SolidColorBrush PastBrush = new(Color.FromRgb(90, 90, 90));
    private static readonly SolidColorBrush ActiveBrush = new(Colors.White);
    private static readonly SolidColorBrush FutureBrush = new(Color.FromRgb(150, 150, 150));

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is not LyricLineState state)
            return FutureBrush;

        return state switch
        {
            LyricLineState.Past => PastBrush,
            LyricLineState.Current => ActiveBrush,
            _ => FutureBrush
        };
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
